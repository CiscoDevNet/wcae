from typing import Literal

ScrollBehavior = Literal[
    'auto',
    'smooth',
]
