from typing import Literal

LetterSpacing = Literal[
    'tighter',
    'tight',
    'normal',
    'wide',
    'wider',
    'widest',
]
