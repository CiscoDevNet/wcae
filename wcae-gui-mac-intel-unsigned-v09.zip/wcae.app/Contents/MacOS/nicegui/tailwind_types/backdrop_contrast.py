from typing import Literal

BackdropContrast = Literal[
    '0',
    '50',
    '75',
    '100',
    '125',
    '150',
    '200',
]
