from typing import Literal

FontSmoothing = Literal[
    'antialiased',
    'subpixel-antialiased',
]
