from typing import Literal

TextDecorationThickness = Literal[
    'auto',
    'from-font',
    '0',
    '1',
    '2',
    '4',
    '8',
]
