from typing import Literal

BoxSizing = Literal[
    'border',
    'content',
]
