from typing import Literal

FlexDirection = Literal[
    'row',
    'row-reverse',
    'col',
    'col-reverse',
]
