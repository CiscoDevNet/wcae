from typing import Literal

Isolation = Literal[
    'isolate',
    'isolation-auto',
]
