from typing import Literal

BackdropHueRotate = Literal[
    '0',
    '15',
    '30',
    '60',
    '90',
    '180',
]
