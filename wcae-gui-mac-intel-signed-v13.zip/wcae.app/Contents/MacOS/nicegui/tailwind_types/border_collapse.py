from typing import Literal

BorderCollapse = Literal[
    'collapse',
    'separate',
]
