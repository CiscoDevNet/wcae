from typing import Literal

ScrollSnapType = Literal[
    'none',
    'x',
    'y',
    'both',
    'mandatory',
    'proximity',
]
