from typing import Literal

Blur = Literal[
    'none',
    'sm',
    '',
    'md',
    'lg',
    'xl',
    '2xl',
    '3xl',
]
