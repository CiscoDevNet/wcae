from typing import Literal

Content = Literal[
    'none',
]
