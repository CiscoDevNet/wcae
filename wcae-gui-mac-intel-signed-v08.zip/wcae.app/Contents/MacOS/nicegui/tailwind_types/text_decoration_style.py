from typing import Literal

TextDecorationStyle = Literal[
    'solid',
    'double',
    'dotted',
    'dashed',
    'wavy',
]
