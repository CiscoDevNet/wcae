from typing import Literal

JustifySelf = Literal[
    'auto',
    'start',
    'end',
    'center',
    'stretch',
]
