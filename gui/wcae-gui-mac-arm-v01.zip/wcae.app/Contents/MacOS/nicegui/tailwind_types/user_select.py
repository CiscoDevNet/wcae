from typing import Literal

UserSelect = Literal[
    'none',
    'text',
    'all',
    'auto',
]
