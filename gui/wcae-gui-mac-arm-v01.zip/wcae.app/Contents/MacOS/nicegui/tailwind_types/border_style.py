from typing import Literal

BorderStyle = Literal[
    'solid',
    'dashed',
    'dotted',
    'double',
    'hidden',
    'none',
]
