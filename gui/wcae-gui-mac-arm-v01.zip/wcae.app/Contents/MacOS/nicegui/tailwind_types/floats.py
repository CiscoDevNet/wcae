from typing import Literal

Floats = Literal[
    'right',
    'left',
    'none',
]
