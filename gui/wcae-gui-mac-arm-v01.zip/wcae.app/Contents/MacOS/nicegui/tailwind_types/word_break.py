from typing import Literal

WordBreak = Literal[
    'normal',
    'words',
    'all',
    'keep',
]
