from typing import Literal

BackdropGrayscale = Literal[
    '0',
    '',
]
