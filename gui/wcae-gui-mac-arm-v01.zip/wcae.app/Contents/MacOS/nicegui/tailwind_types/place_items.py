from typing import Literal

PlaceItems = Literal[
    'start',
    'end',
    'center',
    'baseline',
    'stretch',
]
