from typing import Literal

GridAutoFlow = Literal[
    'row',
    'col',
    'dense',
    'row-dense',
    'col-dense',
]
