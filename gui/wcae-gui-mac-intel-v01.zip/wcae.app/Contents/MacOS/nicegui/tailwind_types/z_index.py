from typing import Literal

ZIndex = Literal[
    '0',
    '10',
    '20',
    '30',
    '40',
    '50',
    'auto',
]
