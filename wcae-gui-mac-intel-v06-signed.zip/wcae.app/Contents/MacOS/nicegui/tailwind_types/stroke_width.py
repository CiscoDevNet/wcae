from typing import Literal

StrokeWidth = Literal[
    '0',
    '1',
    '2',
]
