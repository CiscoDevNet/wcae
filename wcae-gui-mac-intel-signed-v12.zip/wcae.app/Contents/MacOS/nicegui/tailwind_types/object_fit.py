from typing import Literal

ObjectFit = Literal[
    'contain',
    'cover',
    'fill',
    'none',
    'scale-down',
]
