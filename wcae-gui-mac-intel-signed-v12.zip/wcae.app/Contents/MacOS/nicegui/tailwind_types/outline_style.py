from typing import Literal

OutlineStyle = Literal[
    'none',
    '',
    'dashed',
    'dotted',
    'double',
]
