from typing import Literal

DivideStyle = Literal[
    'solid',
    'dashed',
    'dotted',
    'double',
    'none',
]
