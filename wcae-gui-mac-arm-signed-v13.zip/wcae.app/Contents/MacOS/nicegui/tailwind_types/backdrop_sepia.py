from typing import Literal

BackdropSepia = Literal[
    '0',
    '',
]
