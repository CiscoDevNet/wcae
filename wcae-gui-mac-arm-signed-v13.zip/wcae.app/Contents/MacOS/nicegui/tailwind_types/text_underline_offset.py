from typing import Literal

TextUnderlineOffset = Literal[
    'auto',
    '0',
    '1',
    '2',
    '4',
    '8',
]
