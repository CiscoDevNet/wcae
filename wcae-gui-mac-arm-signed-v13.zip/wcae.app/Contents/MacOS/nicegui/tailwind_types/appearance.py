from typing import Literal

Appearance = Literal[
    'none',
    'auto',
]
