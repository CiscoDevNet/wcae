from typing import Literal

MinWidth = Literal[
    '0',
    'full',
    'min',
    'max',
    'fit',
]
