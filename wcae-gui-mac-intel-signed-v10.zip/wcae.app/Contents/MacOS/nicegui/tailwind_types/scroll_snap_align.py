from typing import Literal

ScrollSnapAlign = Literal[
    'start',
    'end',
    'center',
    'align-none',
]
