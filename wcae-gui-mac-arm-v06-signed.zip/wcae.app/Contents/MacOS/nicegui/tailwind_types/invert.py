from typing import Literal

Invert = Literal[
    '0',
    '',
]
