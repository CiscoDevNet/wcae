from typing import Literal

BackgroundOrigin = Literal[
    'border',
    'padding',
    'content',
]
